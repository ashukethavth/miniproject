import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheckIcon, 
  DevicePhoneMobileIcon, 
  CheckCircleIcon,
  ArrowLeftIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';
import { 
  PhoneAuthProvider, 
  PhoneMultiFactorGenerator, 
  RecaptchaVerifier,
  multiFactor
} from 'firebase/auth';
import { auth, db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { useAuth, handleFirestoreError, OperationType } from '../contexts/AuthContext';
import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { Card } from '@/src/components/ui/Card';
import { Container } from '@/src/components/ui/Container';
import { OTPInput } from '@/src/components/ui/OTPInput';

export const SetupMFAPage = () => {
  const navigate = useNavigate();
  const { firebaseUser, user } = useAuth();
  const [step, setStep] = useState(1);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationId, setVerificationId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setIsLoading(true);
    setError(null);

    try {
      const recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible'
      });

      const session = await multiFactor(firebaseUser).getSession();
      const phoneAuthProvider = new PhoneAuthProvider(auth);
      const vId = await phoneAuthProvider.verifyPhoneNumber(
        { phoneNumber, session },
        recaptchaVerifier
      );
      setVerificationId(vId);
      setStep(2);
    } catch (err: any) {
      setError(err.message || 'Failed to send verification code.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async (otp: string) => {
    if (!firebaseUser || !verificationId) return;
    setIsLoading(true);
    setError(null);

    try {
      const cred = PhoneAuthProvider.credential(verificationId, otp);
      const multiFactorAssertion = PhoneMultiFactorGenerator.assertion(cred);
      await multiFactor(firebaseUser).enroll(multiFactorAssertion, 'My Phone');
      
      // Update Firestore user doc
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      await updateDoc(userDocRef, {
        mfaEnabled: true,
        mfaType: 'sms',
        phoneNumber: phoneNumber
      });

      setStep(3);
    } catch (err: any) {
      setError(err.message || 'Invalid verification code.');
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-50">
      <div id="recaptcha-container"></div>
      <Container className="max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="bg-primary-600 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-6">
            <ShieldCheckIcon className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Secure Your Account</h1>
          <p className="text-slate-500 mt-2">Add an extra layer of protection with MFA</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-medium"
            >
              {error}
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center">
                    <DevicePhoneMobileIcon className="h-6 w-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">SMS Authentication</h3>
                    <p className="text-xs text-slate-500">Receive codes via text message</p>
                  </div>
                </div>

                <form onSubmit={handleSendCode} className="space-y-6">
                  <Input
                    label="Phone Number"
                    placeholder="+1 (555) 000-0000"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    required
                  />
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    By continuing, you may receive an SMS for verification. Message and data rates may apply.
                  </p>
                  <div className="flex gap-4">
                    <Button variant="outline" onClick={() => navigate('/security')} className="flex-1 rounded-xl font-bold">
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-[2] rounded-xl font-bold shadow-lg shadow-primary-500/20" isLoading={isLoading}>
                      Send Code
                      <ArrowRightIcon className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </form>
              </Card>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white text-center">
                <h2 className="text-2xl font-bold text-slate-900 mb-2">Verify Phone</h2>
                <p className="text-slate-500 mb-8">
                  Enter the 6-digit code sent to <span className="font-bold text-slate-900">{phoneNumber}</span>
                </p>

                <OTPInput onComplete={handleVerifyCode} className="mb-8" />

                <Button 
                  variant="ghost" 
                  onClick={() => setStep(1)}
                  className="text-slate-500 hover:text-slate-900"
                  disabled={isLoading}
                >
                  <ArrowLeftIcon className="mr-2 h-4 w-4" />
                  Change Number
                </Button>
              </Card>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <Card className="p-12 rounded-[3rem] shadow-2xl border-slate-200/60 bg-white">
                <div className="w-20 h-20 bg-emerald-100 rounded-3xl flex items-center justify-center mx-auto mb-8">
                  <CheckCircleIcon className="h-12 w-12 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">MFA Enabled!</h2>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  Your account is now protected with two-factor authentication. You'll be prompted for a code whenever you sign in.
                </p>
                <Button onClick={() => navigate('/security')} className="w-full py-4 rounded-xl font-bold shadow-lg shadow-primary-500/20">
                  Back to Security Center
                </Button>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </Container>
    </div>
  );
};
