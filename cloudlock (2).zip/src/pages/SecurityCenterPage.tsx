import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ShieldCheckIcon, 
  DevicePhoneMobileIcon, 
  ComputerDesktopIcon, 
  GlobeAltIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  FingerPrintIcon,
  KeyIcon,
  ArrowPathIcon,
  LockClosedIcon,
  ShieldExclamationIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/src/components/ui/Button';
import { Card } from '@/src/components/ui/Card';
import { Container } from '@/src/components/ui/Container';
import { Badge } from '@/src/components/ui/Badge';
import { cn } from '@/src/utils/cn';

const sessions = [
  { id: '1', device: 'MacBook Pro 16"', browser: 'Chrome', location: 'San Francisco, US', ip: '192.168.1.1', status: 'Current Session', lastActive: 'Active now', icon: ComputerDesktopIcon },
  { id: '2', device: 'iPhone 15 Pro', browser: 'Safari', location: 'New York, US', ip: '172.16.0.45', status: 'Active', lastActive: '2 hours ago', icon: DevicePhoneMobileIcon },
  { id: '3', device: 'Windows PC', browser: 'Firefox', location: 'London, UK', ip: '10.0.0.12', status: 'Active', lastActive: '1 day ago', icon: ComputerDesktopIcon },
];

const loginHistory = [
  { id: '1', status: 'success', time: '2024-03-12 14:30', location: 'San Francisco, US', ip: '192.168.1.1', method: 'MFA (Authenticator)' },
  { id: '2', status: 'failed', time: '2024-03-12 10:15', location: 'Moscow, RU', ip: '95.161.224.1', method: 'Password', alert: true },
  { id: '3', status: 'success', time: '2024-03-11 18:45', location: 'San Francisco, US', ip: '192.168.1.1', method: 'MFA (SMS)' },
];

export const SecurityCenterPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const mfaEnabled = user?.mfaEnabled || false;

  return (
    <div className="min-h-screen pt-24 pb-20 bg-slate-50">
      <Container>
        <div className="mb-10">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Security Center</h1>
          <p className="text-slate-500 mt-1">Monitor your account security and manage active sessions.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Security Score */}
            <Card className="p-8 rounded-[2.5rem] bg-slate-900 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/10 rounded-full -mr-32 -mt-32 blur-3xl" />
              <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
                <div className="relative w-40 h-40 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-slate-800" />
                    <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="12" fill="transparent" strokeDasharray={440} strokeDashoffset={440 * (1 - (mfaEnabled ? 0.98 : 0.65))} className="text-primary-500 transition-all duration-1000" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-4xl font-black">{mfaEnabled ? '98' : '65'}</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Score</span>
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-2xl font-bold mb-2">
                    {mfaEnabled ? 'Your security is excellent' : 'Security needs attention'}
                  </h2>
                  <p className="text-slate-400 text-sm leading-relaxed mb-6">
                    {mfaEnabled 
                      ? "We've analyzed your account and found no major vulnerabilities. Keep your MFA enabled and review your sessions regularly."
                      : "Your account security score is lower than recommended. Enable Multi-Factor Authentication to protect your data."}
                  </p>
                  <div className="flex flex-wrap justify-center md:justify-start gap-3">
                    {mfaEnabled ? (
                      <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/20">MFA Enabled</Badge>
                    ) : (
                      <Badge variant="danger" className="bg-rose-500/20 text-rose-400 border-rose-500/20">MFA Disabled</Badge>
                    )}
                    <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/20">Encrypted Vault</Badge>
                    <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/20">Trusted Devices</Badge>
                  </div>
                  {!mfaEnabled && (
                    <Button 
                      onClick={() => navigate('/setup-mfa')}
                      className="mt-6 rounded-xl font-bold shadow-lg shadow-primary-500/20"
                    >
                      Enable MFA Now
                    </Button>
                  )}
                </div>
              </div>
            </Card>

            {/* Active Sessions */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-900">Active Sessions</h3>
                <Button variant="ghost" className="text-rose-500 font-bold text-sm hover:bg-rose-50">Log out all other sessions</Button>
              </div>
              <div className="space-y-4">
                {sessions.map((session) => (
                  <Card key={session.id} className="p-6 rounded-2xl border-slate-200/60 bg-white hover:border-primary-200 transition-colors group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:text-primary-600 transition-colors">
                          <session.icon className="h-6 w-6" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-slate-900">{session.device}</p>
                            <Badge variant={session.status === 'Current Session' ? 'primary' : 'outline'} className="text-[9px] px-1.5">
                              {session.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-500">{session.browser} • {session.location} • {session.ip}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest hidden sm:block">{session.lastActive}</p>
                        {session.status !== 'Current Session' && (
                          <Button variant="outline" size="sm" className="rounded-lg font-bold text-rose-600 hover:bg-rose-50 border-rose-100">Revoke</Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Login History */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-900">Recent Login History</h3>
              <Card className="rounded-2xl border-slate-200/60 bg-white overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      <th className="p-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                      <th className="p-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Time</th>
                      <th className="p-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Location</th>
                      <th className="p-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Method</th>
                      <th className="p-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {loginHistory.map((login) => (
                      <tr key={login.id} className={cn('hover:bg-slate-50/50 transition-colors', login.alert && 'bg-rose-50/30')}>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {login.status === 'success' ? (
                              <ShieldCheckIcon className="h-4 w-4 text-emerald-500" />
                            ) : (
                              <ShieldExclamationIcon className="h-4 w-4 text-rose-500" />
                            )}
                            <span className={cn('text-xs font-bold capitalize', login.status === 'success' ? 'text-emerald-600' : 'text-rose-600')}>
                              {login.status}
                            </span>
                          </div>
                        </td>
                        <td className="p-4 text-xs font-medium text-slate-600">{login.time}</td>
                        <td className="p-4 text-xs font-medium text-slate-600">{login.location} ({login.ip})</td>
                        <td className="p-4 text-xs font-medium text-slate-600">{login.method}</td>
                        <td className="p-4 text-right">
                          <button className="text-primary-600 hover:underline text-[10px] font-bold uppercase tracking-widest">Details</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </div>
          </div>

          <div className="space-y-8">
            {/* Security Alerts */}
            <Card className="p-8 rounded-[2.5rem] border-slate-200/60 bg-white shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-slate-900">Security Alerts</h3>
                <Badge variant="danger">1 New</Badge>
              </div>
              <div className="space-y-4">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex gap-3">
                  <ExclamationTriangleIcon className="h-5 w-5 text-rose-600 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-rose-900">Failed Login Attempt</p>
                    <p className="text-[10px] text-rose-700 mt-1">A failed login was detected from Moscow, RU. We've blocked this IP address.</p>
                  </div>
                </div>
                <div className="p-4 bg-primary-50 rounded-2xl border border-primary-100 flex gap-3">
                  <ShieldCheckIcon className="h-5 w-5 text-primary-600 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-primary-900">New Device Trusted</p>
                    <p className="text-[10px] text-primary-700 mt-1">Your iPhone 15 Pro was added to trusted devices on March 10.</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Quick Settings */}
            <Card className="p-8 rounded-[2.5rem] border-slate-200/60 bg-white shadow-sm">
              <h3 className="text-lg font-bold text-slate-900 mb-6">Quick Settings</h3>
              <div className="space-y-2">
                {[
                  { label: 'Multi-Factor Auth', icon: FingerPrintIcon, status: mfaEnabled ? 'Enabled' : 'Disabled', action: () => navigate('/setup-mfa') },
                  { label: 'Master Key Status', icon: KeyIcon, status: 'Secure' },
                  { label: 'Auto-Locking', icon: LockClosedIcon, status: '5 mins' },
                  { label: 'Session Timeout', icon: ClockIcon, status: '24 hours' },
                ].map((item) => (
                  <button 
                    key={item.label} 
                    onClick={item.action}
                    className="w-full flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="h-5 w-5 text-slate-400 group-hover:text-primary-600" />
                      <span className="text-sm font-medium text-slate-700 group-hover:text-slate-900">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.status}</span>
                      <ChevronRightIcon className="h-4 w-4 text-slate-300" />
                    </div>
                  </button>
                ))}
              </div>
              <div className="mt-8 pt-6 border-t border-slate-100">
                <Button className="w-full rounded-xl font-bold">
                  <ArrowPathIcon className="h-5 w-5 mr-2" />
                  Update Master Key
                </Button>
              </div>
            </Card>

            {/* Compliance */}
            <Card className="p-8 rounded-[2.5rem] bg-emerald-900 text-white">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-white/10 rounded-lg">
                  <GlobeAltIcon className="h-6 w-6 text-emerald-400" />
                </div>
                <h3 className="text-lg font-bold">Compliance</h3>
              </div>
              <p className="text-sm text-emerald-100/60 leading-relaxed mb-6">
                Your account meets HIPAA and GDPR data protection standards.
              </p>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span>GDPR Readiness</span>
                  <span className="font-bold">100%</span>
                </div>
                <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400 w-full" />
                </div>
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </div>
  );
};
