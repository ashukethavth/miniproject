import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  UserCircleIcon, 
  CameraIcon, 
  EnvelopeIcon, 
  BuildingOfficeIcon,
  GlobeAltIcon,
  ShieldCheckIcon,
  DevicePhoneMobileIcon,
  PencilSquareIcon
} from '@heroicons/react/24/outline';
import { updateProfile } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth, handleFirestoreError, OperationType } from '../contexts/AuthContext';
import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { Card } from '@/src/components/ui/Card';
import { Container } from '@/src/components/ui/Container';
import { Badge } from '@/src/components/ui/Badge';
import { cn } from '@/src/utils/cn';

export const ProfilePage = () => {
  const { firebaseUser, user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    organization: '',
    role: '',
    location: '',
    phone: ''
  });

  useEffect(() => {
    if (user) {
      setProfile({
        name: user.displayName || '',
        email: user.email || '',
        organization: user.organization || '',
        role: user.role || 'User',
        location: user.location || '',
        phone: user.phoneNumber || ''
      });
    }
  }, [user]);

  const handleSave = async () => {
    if (!firebaseUser) return;
    setIsLoading(true);
    setError(null);

    try {
      // Update Firebase Auth Profile
      await updateProfile(firebaseUser, {
        displayName: profile.name
      });

      // Update Firestore User Doc
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      await updateDoc(userDocRef, {
        displayName: profile.name,
        organization: profile.organization,
        location: profile.location,
        phoneNumber: profile.phone
      });

      setIsEditing(false);
    } catch (err: any) {
      setError(err.message || 'Failed to update profile.');
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-50">
      <Container>
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium">
            {error}
          </div>
        )}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            <Card className="p-8 rounded-[2.5rem] text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-primary-600 to-indigo-600" />
              <div className="relative mt-8">
                <div className="w-32 h-32 rounded-[2.5rem] border-4 border-white shadow-xl mx-auto overflow-hidden relative group">
                  <img 
                    src={firebaseUser?.photoURL || `https://picsum.photos/seed/${firebaseUser?.uid}/200/200`} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                  <button className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <CameraIcon className="h-8 w-8 text-white" />
                  </button>
                </div>
                <div className="absolute bottom-0 right-1/3 translate-x-1/2 translate-y-1/2">
                  <Badge variant="primary" className="px-3 py-1 border-2 border-white shadow-lg">
                    {firebaseUser?.emailVerified ? 'Verified' : 'Unverified'}
                  </Badge>
                </div>
              </div>
              
              <div className="mt-8">
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{profile.name}</h2>
                <p className="text-slate-500 font-medium">{profile.role}</p>
              </div>

              <div className="mt-8 pt-8 border-t border-slate-100 space-y-4">
                <div className="flex items-center gap-3 text-slate-600">
                  <BuildingOfficeIcon className="h-5 w-5 text-slate-400" />
                  <span className="text-sm">{profile.organization || 'No Organization'}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-600">
                  <GlobeAltIcon className="h-5 w-5 text-slate-400" />
                  <span className="text-sm">{profile.location || 'No Location'}</span>
                </div>
              </div>
            </Card>

            <Card className="p-8 rounded-[2.5rem] bg-slate-900 text-white">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                <ShieldCheckIcon className="h-5 w-5 text-primary-400" />
                Security Score
              </h3>
              <div className="flex items-center justify-between mb-2">
                <span className="text-4xl font-black tracking-tighter">{user?.mfaEnabled ? '98%' : '65%'}</span>
                <Badge variant="primary" className="bg-primary-500/20 text-primary-300 border-primary-500/30">
                  {user?.mfaEnabled ? 'Excellent' : 'Needs Attention'}
                </Badge>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2 mb-6">
                <div className={cn('h-2 rounded-full transition-all duration-1000', user?.mfaEnabled ? 'bg-primary-500 w-[98%]' : 'bg-rose-500 w-[65%]')} />
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {user?.mfaEnabled 
                  ? "Your account security is higher than 95% of users. Keep it up!"
                  : "Enable Multi-Factor Authentication to significantly improve your security score."}
              </p>
            </Card>
          </div>

          {/* Profile Details */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="p-10 rounded-[2.5rem] shadow-xl border-slate-200/60 bg-white">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Personal Information</h2>
                {!isEditing ? (
                  <Button variant="outline" onClick={() => setIsEditing(true)} className="rounded-xl font-bold">
                    <PencilSquareIcon className="h-5 w-5 mr-2" />
                    Edit Profile
                  </Button>
                ) : (
                  <div className="flex gap-3">
                    <Button variant="ghost" onClick={() => setIsEditing(false)} className="font-bold">Cancel</Button>
                    <Button onClick={handleSave} isLoading={isLoading} className="rounded-xl font-bold px-8 shadow-lg shadow-primary-500/20">Save Changes</Button>
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <Input
                  label="Full Name"
                  value={profile.name}
                  disabled={!isEditing}
                  icon={UserCircleIcon}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                />
                <Input
                  label="Email Address"
                  type="email"
                  value={profile.email}
                  disabled={true} // Email should be updated via specific flow
                  icon={EnvelopeIcon}
                />
                <Input
                  label="Organization"
                  value={profile.organization}
                  disabled={!isEditing}
                  icon={BuildingOfficeIcon}
                  onChange={(e) => setProfile({ ...profile, organization: e.target.value })}
                />
                <Input
                  label="Phone Number"
                  value={profile.phone}
                  disabled={!isEditing}
                  icon={DevicePhoneMobileIcon}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                />
                <div className="md:col-span-2">
                  <Input
                    label="Location"
                    value={profile.location}
                    disabled={!isEditing}
                    icon={GlobeAltIcon}
                    onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                  />
                </div>
              </div>
            </Card>

            <Card className="p-10 rounded-[2.5rem] shadow-xl border-slate-200/60 bg-white">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-8">Account Activity</h2>
              <div className="space-y-6">
                {[
                  { event: 'Successful Login', device: 'Chrome on macOS', time: '2 minutes ago', status: 'success' },
                  { event: 'Password Changed', device: 'Safari on iPhone', time: '2 days ago', status: 'warning' },
                  { event: 'MFA Enabled', device: 'Chrome on macOS', time: '1 week ago', status: 'success' },
                ].map((log, i) => (
                  <div key={i} className="flex items-center justify-between py-4 border-b border-slate-50 last:border-0">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        'w-10 h-10 rounded-xl flex items-center justify-center',
                        log.status === 'success' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                      )}>
                        <ShieldCheckIcon className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{log.event}</p>
                        <p className="text-xs text-slate-500">{log.device}</p>
                      </div>
                    </div>
                    <span className="text-xs font-medium text-slate-400">{log.time}</span>
                  </div>
                ))}
              </div>
              <Button variant="ghost" className="w-full mt-6 text-primary-600 font-bold">View All Activity</Button>
            </Card>
          </div>
        </div>
      </Container>
    </div>
  );
};
