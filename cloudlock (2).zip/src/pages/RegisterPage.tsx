import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheckIcon, 
  LockClosedIcon, 
  EnvelopeIcon, 
  UserIcon,
  BuildingOfficeIcon,
  CheckCircleIcon,
  ArrowRightIcon,
  ArrowLeftIcon
} from '@heroicons/react/24/outline';
import { 
  createUserWithEmailAndPassword, 
  updateProfile, 
  sendEmailVerification 
} from 'firebase/auth';
import { auth } from '../firebase';
import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { Card } from '@/src/components/ui/Card';
import { PasswordStrength } from '@/src/components/ui/PasswordStrength';
import { Container } from '@/src/components/ui/Container';
import { cn } from '@/src/utils/cn';

export const RegisterPage = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false
  });

  const handleNext = () => {
    if (step === 1 && (!formData.name || !formData.email)) {
      setError('Please fill in all required fields.');
      return;
    }
    setError(null);
    setStep(step + 1);
  };
  const handleBack = () => setStep(step - 1);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;

      await updateProfile(user, {
        displayName: formData.name
      });

      await sendEmailVerification(user);
      
      setStep(3); // Success state
    } catch (err: any) {
      setError(err.message || 'Failed to create account.');
    } finally {
      setIsLoading(false);
    }
  };

  const steps = [
    { id: 1, title: 'Identity' },
    { id: 2, title: 'Security' },
    { id: 3, title: 'Verify' }
  ];

  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-50 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-primary-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-200/30 rounded-full blur-3xl" />
      </div>

      <Container className="max-w-xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <Link to="/" className="inline-flex items-center gap-2 mb-6 group">
            <div className="bg-primary-600 p-2 rounded-xl group-hover:rotate-12 transition-transform">
              <ShieldCheckIcon className="h-8 w-8 text-white" />
            </div>
            <span className="text-3xl font-black tracking-tighter text-slate-900">CloudLock</span>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Create Secure Account</h1>
          
          {/* Progress Indicator */}
          <div className="flex justify-center items-center gap-4 mt-8">
            {steps.map((s, i) => (
              <React.Fragment key={s.id}>
                <div className="flex items-center gap-2">
                  <div className={cn(
                    'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-500',
                    step >= s.id ? 'bg-primary-600 text-white shadow-lg shadow-primary-500/20' : 'bg-slate-200 text-slate-500'
                  )}>
                    {step > s.id ? '✓' : s.id}
                  </div>
                  <span className={cn(
                    'text-xs font-bold uppercase tracking-widest hidden sm:block',
                    step >= s.id ? 'text-primary-600' : 'text-slate-400'
                  )}>
                    {s.title}
                  </span>
                </div>
                {i < steps.length - 1 && (
                  <div className={cn(
                    'w-8 h-0.5 rounded-full transition-all duration-500',
                    step > s.id ? 'bg-primary-600' : 'bg-slate-200'
                  )} />
                )}
              </React.Fragment>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-medium"
            >
              {error}
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white/80 backdrop-blur-xl">
                <div className="space-y-6">
                  <Input
                    label="Full Name"
                    placeholder="John Doe"
                    icon={UserIcon}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  <Input
                    label="Work Email"
                    type="email"
                    placeholder="john@company.com"
                    icon={EnvelopeIcon}
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                  <Input
                    label="Organization"
                    placeholder="Acme Corp"
                    icon={BuildingOfficeIcon}
                    value={formData.organization}
                    onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                  />
                  <Button onClick={handleNext} className="w-full py-4 rounded-xl text-lg font-bold shadow-lg shadow-primary-500/20">
                    Continue to Security
                    <ArrowRightIcon className="ml-2 h-5 w-5" />
                  </Button>
                </div>
                <div className="mt-8 pt-8 border-t border-slate-100 text-center">
                  <p className="text-slate-500 text-sm">
                    Already have an account?{' '}
                    <Link to="/login" className="font-bold text-primary-600 hover:text-primary-700">
                      Sign In
                    </Link>
                  </p>
                </div>
              </Card>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white/80 backdrop-blur-xl">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <Input
                      label="Create Password"
                      type="password"
                      placeholder="••••••••"
                      icon={LockClosedIcon}
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    />
                    <PasswordStrength password={formData.password} />
                  </div>
                  
                  <label className="flex items-start gap-3 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={formData.acceptTerms}
                      onChange={(e) => setFormData({ ...formData, acceptTerms: e.target.checked })}
                      className="mt-1 w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" 
                    />
                    <span className="text-sm text-slate-500 leading-relaxed">
                      I agree to the <Link to="/terms" className="text-primary-600 font-bold">Terms of Service</Link> and <Link to="/privacy" className="text-primary-600 font-bold">Privacy Policy</Link>.
                    </span>
                  </label>

                  <div className="flex gap-4">
                    <Button variant="outline" onClick={handleBack} className="flex-1 py-4 rounded-xl font-bold">
                      <ArrowLeftIcon className="mr-2 h-5 w-5" />
                      Back
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-[2] py-4 rounded-xl font-bold shadow-lg shadow-primary-500/20"
                      isLoading={isLoading}
                      disabled={!formData.acceptTerms}
                    >
                      Create Account
                    </Button>
                  </div>
                </form>
              </Card>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <Card className="p-12 rounded-[3rem] shadow-2xl border-slate-200/60 bg-white/80 backdrop-blur-xl">
                <div className="w-20 h-20 bg-emerald-100 rounded-3xl flex items-center justify-center mx-auto mb-8">
                  <CheckCircleIcon className="h-12 w-12 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Account Created!</h2>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  We've sent a verification link to <span className="font-bold text-slate-900">{formData.email}</span>. 
                  Please check your inbox to activate your account.
                </p>
                <div className="space-y-4">
                  <Button onClick={() => navigate('/login')} className="w-full py-4 rounded-xl font-bold shadow-lg shadow-primary-500/20">
                    Go to Login
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </Container>
    </div>
  );
};
