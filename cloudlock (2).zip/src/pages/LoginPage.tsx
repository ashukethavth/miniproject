import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheckIcon, 
  LockClosedIcon, 
  EnvelopeIcon, 
  EyeIcon, 
  EyeSlashIcon,
  ArrowRightIcon,
  DevicePhoneMobileIcon
} from '@heroicons/react/24/outline';
import { 
  signInWithEmailAndPassword, 
  getMultiFactorResolver, 
  PhoneAuthProvider, 
  PhoneMultiFactorGenerator,
  RecaptchaVerifier
} from 'firebase/auth';
import { auth } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { Card } from '@/src/components/ui/Card';
import { SecurityNotice } from '@/src/components/ui/SecurityNotice';
import { OTPInput } from '@/src/components/ui/OTPInput';
import { Container } from '@/src/components/ui/Container';

export const LoginPage = () => {
  const navigate = useNavigate();
  const { setResolver, resolver } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [isMfaRequired, setIsMfaRequired] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [verificationId, setVerificationId] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      if (err.code === 'auth/multi-factor-auth-required') {
        const resolver = getMultiFactorResolver(auth, err);
        setResolver(resolver);
        
        // For simplicity in this demo, we assume the user has SMS MFA
        // In a real app, you'd check resolver.hints to see which factors are available
        const phoneInfoOptions = resolver.hints[0];
        
        if (phoneInfoOptions.factorId === PhoneMultiFactorGenerator.FACTOR_ID) {
          const recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            size: 'invisible'
          });
          
          const phoneAuthProvider = new PhoneAuthProvider(auth);
          const vId = await phoneAuthProvider.verifyPhoneNumber(
            { multiFactorHint: phoneInfoOptions, session: resolver.session },
            recaptchaVerifier
          );
          setVerificationId(vId);
          setIsMfaRequired(true);
        }
      } else {
        setError(err.message || 'Failed to sign in. Please check your credentials.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleMfaComplete = async (otp: string) => {
    setIsLoading(true);
    setError(null);
    try {
      if (!resolver || !verificationId) return;

      const cred = PhoneAuthProvider.credential(verificationId, otp);
      const multiFactorAssertion = PhoneMultiFactorGenerator.assertion(cred);
      await resolver.resolveWithMultiFactor(multiFactorAssertion);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Invalid MFA code.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-50 relative overflow-hidden">
      <div id="recaptcha-container"></div>
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-200/30 rounded-full blur-3xl" />
      </div>

      <Container className="max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <Link to="/" className="inline-flex items-center gap-2 mb-6 group">
            <div className="bg-primary-600 p-2 rounded-xl group-hover:rotate-12 transition-transform">
              <ShieldCheckIcon className="h-8 w-8 text-white" />
            </div>
            <span className="text-3xl font-black tracking-tighter text-slate-900">CloudLock</span>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Welcome Back</h1>
          <p className="text-slate-500 mt-2">Access your secure cloud environment</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-medium"
            >
              {error}
            </motion.div>
          )}

          {!isMfaRequired ? (
            <motion.div
              key="login-form"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white/80 backdrop-blur-xl">
                <form onSubmit={handleLogin} className="space-y-6">
                  <Input
                    label="Email Address"
                    type="email"
                    placeholder="name@company.com"
                    icon={EnvelopeIcon}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                  <div className="relative">
                    <Input
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      icon={LockClosedIcon}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-[38px] text-slate-400 hover:text-slate-600 transition-colors"
                    >
                      {showPassword ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500" 
                      />
                      <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">Remember device</span>
                    </label>
                    <Link to="/forgot-password" title="Reset your password" className="text-sm font-bold text-primary-600 hover:text-primary-700">
                      Forgot Password?
                    </Link>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full py-4 rounded-xl text-lg font-bold shadow-lg shadow-primary-500/20"
                    isLoading={isLoading}
                  >
                    Sign In
                    <ArrowRightIcon className="ml-2 h-5 w-5" />
                  </Button>
                </form>

                <div className="mt-8 pt-8 border-t border-slate-100 text-center">
                  <p className="text-slate-500 text-sm">
                    Don't have an account?{' '}
                    <Link to="/register" className="font-bold text-primary-600 hover:text-primary-700">
                      Create Account
                    </Link>
                  </p>
                </div>
              </Card>
              <SecurityNotice className="mt-6" />
            </motion.div>
          ) : (
            <motion.div
              key="mfa-form"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 rounded-[2rem] shadow-xl border-slate-200/60 bg-white/80 backdrop-blur-xl text-center">
                <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <DevicePhoneMobileIcon className="h-8 w-8 text-primary-600" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">Two-Factor Auth</h2>
                <p className="text-slate-500 mb-8">
                  Enter the 6-digit code sent to your phone
                </p>

                <OTPInput onComplete={handleMfaComplete} className="mb-8" />

                <Button 
                  variant="ghost" 
                  onClick={() => setIsMfaRequired(false)}
                  className="text-slate-500 hover:text-slate-900"
                >
                  Back to Login
                </Button>

                <div className="mt-8 pt-8 border-t border-slate-100">
                  <p className="text-xs text-slate-400">
                    Lost your device? <Link to="/support" className="text-primary-600 font-bold">Contact Support</Link>
                  </p>
                </div>
              </Card>
              <SecurityNotice 
                className="mt-6" 
                message="Multi-factor authentication adds an extra layer of security to your account." 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </Container>
    </div>
  );
};
