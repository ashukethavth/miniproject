import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheckIcon, 
  DocumentIcon, 
  UserGroupIcon, 
  ArrowUpTrayIcon,
  ClockIcon,
  ChartBarIcon,
  ExclamationTriangleIcon,
  ArrowRightIcon,
  PlusIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';
import { Button } from '@/src/components/ui/Button';
import { Card } from '@/src/components/ui/Card';
import { Container } from '@/src/components/ui/Container';
import { Badge } from '@/src/components/ui/Badge';
import { cn } from '@/src/utils/cn';

const stats = [
  { label: 'Total Files', value: '1,284', icon: DocumentIcon, color: 'text-blue-600', bg: 'bg-blue-50' },
  { label: 'Storage Used', value: '1.5 GB / 2 GB', icon: ChartBarIcon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  { label: 'Active Shares', value: '24', icon: UserGroupIcon, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { label: 'Security Score', value: '98/100', icon: ShieldCheckIcon, color: 'text-primary-600', bg: 'bg-primary-50' },
];

const recentFiles = [
  { id: '1', name: 'Q1_Financial_Report.pdf', type: 'pdf', size: '2.4 MB', date: '2 hours ago' },
  { id: '2', name: 'Product_Launch_Video.mp4', type: 'video', size: '85 MB', date: '5 hours ago' },
  { id: '3', name: 'Hero_Banner_v2.png', type: 'image', size: '4.2 MB', date: 'Yesterday' },
  { id: '4', name: 'Main_Styles.css', type: 'code', size: '12 KB', date: '2 days ago' },
];

const activities = [
  { id: '1', user: 'Ashwitha K.', action: 'uploaded', target: 'Q1_Financial_Report.pdf', time: '2h ago' },
  { id: '2', user: 'System', action: 'blocked', target: 'Unauthorized login attempt', time: '4h ago', alert: true },
  { id: '3', user: 'John D.', action: 'downloaded', target: 'Product_Specs.docx', time: '5h ago' },
  { id: '4', user: 'Ashwitha K.', action: 'shared', target: 'Marketing Folder', time: '1d ago' },
];

export const Dashboard = () => {
  return (
    <div className="min-h-screen pt-24 pb-20 bg-slate-50">
      <Container>
        {/* Welcome Header */}
        <div className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-3xl font-black text-slate-900 tracking-tight"
            >
              Welcome back, Ashwitha
            </motion.h1>
            <p className="text-slate-500 mt-1">Your cloud environment is secure and up to date.</p>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/upload">
              <Button className="rounded-xl font-bold shadow-lg shadow-primary-500/20">
                <PlusIcon className="h-5 w-5 mr-2" />
                Quick Upload
              </Button>
            </Link>
            <Button variant="outline" className="rounded-xl font-bold">
              <ChartBarIcon className="h-5 w-5 mr-2" />
              Reports
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="p-6 rounded-[2rem] border-slate-200/60 bg-white hover:shadow-xl transition-all group">
                <div className="flex items-center gap-4">
                  <div className={cn('p-3 rounded-2xl transition-transform group-hover:scale-110', stat.bg, stat.color)}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                    <p className="text-xl font-black text-slate-900">{stat.value}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Files */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-900">Recent Files</h2>
              <Link to="/files" className="text-sm font-bold text-primary-600 hover:underline flex items-center gap-1">
                View All <ArrowRightIcon className="h-4 w-4" />
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {recentFiles.map((file) => (
                <Card key={file.id} className="p-4 rounded-2xl border-slate-200/60 bg-white hover:border-primary-200 transition-colors group cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center group-hover:bg-primary-50 transition-colors">
                      <DocumentIcon className="h-6 w-6 text-slate-400 group-hover:text-primary-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-slate-900 truncate text-sm">{file.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{file.size}</span>
                        <span className="text-[10px] text-slate-300">•</span>
                        <span className="text-[10px] text-slate-400">{file.date}</span>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Storage Visualization */}
            <Card className="p-8 rounded-[2.5rem] border-slate-200/60 bg-white shadow-sm">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-lg font-bold text-slate-900">Storage Usage</h3>
                <Badge variant="outline">75% Used</Badge>
              </div>
              <div className="space-y-6">
                <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex">
                  <div className="h-full bg-blue-500 w-[40%]" />
                  <div className="h-full bg-indigo-500 w-[20%]" />
                  <div className="h-full bg-emerald-500 w-[10%]" />
                  <div className="h-full bg-amber-500 w-[5%]" />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {[
                    { label: 'Documents', size: '600 MB', color: 'bg-blue-500' },
                    { label: 'Videos', size: '300 MB', color: 'bg-indigo-500' },
                    { label: 'Images', size: '150 MB', color: 'bg-emerald-500' },
                    { label: 'Others', size: '75 MB', color: 'bg-amber-500' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-2">
                      <div className={cn('w-2 h-2 rounded-full', item.color)} />
                      <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.label}</p>
                        <p className="text-xs font-bold text-slate-900">{item.size}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          {/* Activity Feed */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-slate-900">Activity Feed</h2>
            <Card className="p-6 rounded-[2.5rem] border-slate-200/60 bg-white shadow-sm">
              <div className="space-y-6">
                {activities.map((activity) => (
                  <div key={activity.id} className="flex gap-4 relative">
                    <div className={cn(
                      'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10',
                      activity.alert ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-600'
                    )}>
                      {activity.alert ? <ExclamationTriangleIcon className="h-4 w-4" /> : <ClockIcon className="h-4 w-4" />}
                    </div>
                    <div className="flex-1 pb-6 border-b border-slate-50 last:border-0">
                      <p className="text-sm text-slate-900">
                        <span className="font-bold">{activity.user}</span> {activity.action} <span className="font-medium text-primary-600">{activity.target}</span>
                      </p>
                      <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase tracking-widest">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="ghost" className="w-full mt-4 text-primary-600 font-bold text-sm">
                View Full Audit Log
              </Button>
            </Card>

            {/* Security Widget */}
            <Card className="p-8 rounded-[2.5rem] bg-slate-900 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/10 rounded-full -mr-16 -mt-16 blur-3xl" />
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-primary-500/20 rounded-lg">
                    <ShieldCheckIcon className="h-6 w-6 text-primary-400" />
                  </div>
                  <h3 className="text-lg font-bold">Security Status</h3>
                </div>
                <div className="space-y-4 mb-8">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-400">MFA Status</span>
                    <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/20">Active</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-400">Encryption</span>
                    <Badge variant="success" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/20">AES-256</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-400">Threat Level</span>
                    <Badge variant="outline" className="text-emerald-400 border-emerald-500/20">Low</Badge>
                  </div>
                </div>
                <Button className="w-full bg-white text-slate-900 hover:bg-slate-100 font-bold rounded-xl">
                  Run Security Audit
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </div>
  );
};
