import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { PublicLayout } from './components/layout/PublicLayout';
import { AppLayout } from './components/layout/AppLayout';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { VerifyEmailPage } from './pages/VerifyEmailPage';
import { SetupMFAPage } from './pages/SetupMFAPage';
import { ProfilePage } from './pages/ProfilePage';
import { SettingsPage } from './pages/SettingsPage';
import { UploadPage } from './pages/UploadPage';
import { FileManagerPage } from './pages/FileManagerPage';
import { FileDetailsPage } from './pages/FileDetailsPage';
import { Dashboard } from './pages/Dashboard';
import { SharingPage } from './pages/SharingPage';
import { SecurityCenterPage } from './pages/SecurityCenterPage';
import { AuditLogsPage } from './pages/AuditLogsPage';
import { AdminPage } from './pages/AdminPage';
import { SupportPage } from './pages/SupportPage';

const PageWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.3, ease: "easeOut" }}
  >
    {children}
  </motion.div>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      <div key={location.pathname}>
        <Routes location={location}>
          {/* Public Routes */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<PageWrapper><LandingPage /></PageWrapper>} />
          <Route path="/login" element={<PageWrapper><LoginPage /></PageWrapper>} />
          <Route path="/register" element={<PageWrapper><RegisterPage /></PageWrapper>} />
          <Route path="/verify-email" element={<PageWrapper><VerifyEmailPage /></PageWrapper>} />
          <Route path="/setup-mfa" element={<PageWrapper><SetupMFAPage /></PageWrapper>} />
          <Route path="/features" element={<PageWrapper><div className="p-20 text-center">Features Page (Coming Soon)</div></PageWrapper>} />
          <Route path="/compliance" element={<PageWrapper><div className="p-20 text-center">Compliance Page (Coming Soon)</div></PageWrapper>} />
          <Route path="/pricing" element={<PageWrapper><div className="p-20 text-center">Pricing Page (Coming Soon)</div></PageWrapper>} />
        </Route>

        {/* App Routes (Authenticated) */}
        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/dashboard" element={<PageWrapper><Dashboard /></PageWrapper>} />
          <Route path="/files" element={<PageWrapper><FileManagerPage /></PageWrapper>} />
          <Route path="/files/:id" element={<PageWrapper><FileDetailsPage /></PageWrapper>} />
          <Route path="/upload" element={<PageWrapper><UploadPage /></PageWrapper>} />
          <Route path="/share" element={<PageWrapper><SharingPage /></PageWrapper>} />
          <Route path="/security" element={<PageWrapper><SecurityCenterPage /></PageWrapper>} />
          <Route path="/audit" element={<PageWrapper><AuditLogsPage /></PageWrapper>} />
          <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminPage /></ProtectedRoute>} />
          <Route path="/support" element={<PageWrapper><SupportPage /></PageWrapper>} />
          <Route path="/profile" element={<PageWrapper><ProfilePage /></PageWrapper>} />
          <Route path="/settings" element={<PageWrapper><SettingsPage /></PageWrapper>} />
          <Route path="/access" element={<Navigate to="/security" replace />} />
          <Route path="/compliance-tracking" element={<Navigate to="/audit" replace />} />
          <Route path="/team" element={<Navigate to="/admin" replace />} />
          <Route path="/reports" element={<Navigate to="/audit" replace />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </div>
    </AnimatePresence>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AnimatedRoutes />
      </Router>
    </AuthProvider>
  );
}
